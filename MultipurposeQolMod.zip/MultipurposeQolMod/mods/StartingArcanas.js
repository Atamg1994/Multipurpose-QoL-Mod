const Core = {
    Update() {
		try{
		const _0x466e41 = self.Game;
		   const _0x5f0f62 = _0x495140;
                        for (let _0x914f31 = 0; _0x914f31 < this['PickupsWithArrows']['children']['entries']['length']; _0x914f31++)
                            this['PickupsWithArrows']['children']['entries'][_0x914f31]['Update'](_0x472042);
						
                        var _0x1c98af = !1;
                        if (this['updateTick']++, this['updateTick'] % this['updateFreq'] == 0 && (this['updateTick'] = 0, _0x1c98af = !0), _0x1c98af) {
                            var _0x85eac6 = this['LevelUpFactory']['XpRequiredToLevelUp'];
                            if (this['canInterrupt']) {
								 console.log('canInterrupt')
                                if (this['canPause'] && this['enterPause'])
                                    (console.log('enterPause')),this['enterPause'] = !1, _0x466e41['default']['Core']['SceneManager']['EnterPause']();
                                else {
                                    if (this['EnterWeaponSelection'])
                                        (console.log('EnterWeaponSelection')),this['EnterWeaponSelection'] = !1, this['SceneManager']['EnterWeaponSelection']();
                                    else {
                                        if (this['StartShopScene'])
                                            (console.log('StartShopScene')),this['StartShopScene'] = !1, this['SceneManager']['EnterShop']();
                                        else {
                                            if (this['StartHealerScene'])
                                                (console.log('StartHealerScene')), this['StartHealerScene'] = !1, this['SceneManager']['EnterHealer']();
                                            else {
                                                if (this['StartDirecterScene'])
                                                  (console.log('StartDirecterScene')),  this['StartDirecterScene'] = !1, this['SceneManager']['EnterDirecter']();
                                                else {
													if (this['GiveMainArcana'] && this['GiveMainArcana'] <= (this.Player.level === 1 ? this.PlayerOptions.qolModOptions.startingArcanas : 1))
                                                        (console.log('GiveMainArcana')),(this.GiveMainArcana += 1), _0x466e41['default']['Core']['PlayerOptions']['UnlockedArcanas']['length'] > _0x466e41['default']['Core']['Arcanas']['ActiveArcanas']['length'] && _0x466e41['default']['Core']['SceneManager']['EnterMainArcana']();
                                                    else {
                                                        if (this['GiveDraftArcana'])
                                                         (console.log('GiveDraftArcana')),    this['GiveDraftArcana'] = !1, _0x466e41['default']['Core']['PlayerOptions']['UnlockedArcanas']['length'] > _0x466e41['default']['Core']['Arcanas']['ActiveArcanas']['length'] && _0x466e41['default']['Core']['SceneManager']['EnterDraftArcana']();
                                                        else {
                                                            if (this['Player']['xp'] >= _0x85eac6)
                                                                this['Player']['LevelUp'](),
																this['SwapToLevelUpScene'](),
																this['LootManager']['RecalculateLoot'](),
																this['LevelUpFactory']['CalculateXPfactor'](),
																this['PlayerUI']['Update'](),
																this['MainUI']['UpdatePlayerLevel']();
                                                            else {
                                                                if (this['TreasureQueue']['length'] > 0) {
                                                                    let _0x2e0d7b = this['TreasureQueue']['pop']();
                                                                    this['CurrentTreasureLevel'] = _0x2e0d7b['level'], this['CurrentTreasureTypes'] = _0x2e0d7b['prizeTypes'], this['CurrentFixedTreasures'] = _0x2e0d7b['fixedPrizes'], _0x466e41['default']['Core']['SceneManager']['StartTreasureScene']();
                                                                } else
                                                                    this['RelicQueue']['length'] > 0 ? (this['CurrentFoundRelic'] = this['RelicQueue']['pop'](),
																	this['SwapToRelicFoundScene']()) : this['FoundWeaponQueue']['length'] > 0 ? (this['CurrentFoundItem'] = this['FoundWeaponQueue']['pop'](),
																	this['SwapToItemFoundScene']()) : this['CharQueue']['length'] > 0 && (this['CurrentFoundChar'] = this['CharQueue']['pop'](),
																	this['CharQueue'] = new Array(), this['SwapToCharFoundScene']());
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            this['Stage']['dayNight'] && this['BGMan']['DayNightHue']();
                            for (let _0x5cbb78 = 0; _0x5cbb78 < this['PickupGroup']['children']['entries']['length']; _0x5cbb78++)
                                this['PickupGroup']['children']['entries'][_0x5cbb78]['Update'](_0x472042);
                            for (let _0x1a6773 = 0; _0x1a6773 < this['explosionPool']['spawned']['length']; _0x1a6773++)
                                this['explosionPool']['spawned'][_0x1a6773]['Update'](_0x472042);
                        } else
                            this['canPause'] && this['enterPause'] && 
						   (this['enterPause'] = !1, _0x466e41['default']['Core']['SceneManager']['EnterPause']());
                        for (let _0x1180dc = 0; _0x1180dc < this['BulletGroup']['children']['entries']['length']; _0x1180dc++)
                            this['BulletGroup']['children']['entries'][_0x1180dc]['Update'](_0x472042);
                        for (let _0x57d36c = 0; _0x57d36c < this['Weapons']['length']; _0x57d36c++)
                            this['Weapons'][_0x57d36c]['Update'](_0x472042);
                        for (let _0x124c4e = this['HiddenWeapons']['length'] - 1; _0x124c4e >= 0; _0x124c4e--)
                            this['HiddenWeapons'][_0x124c4e]['Update'](_0x472042);
							this['Player']['Update'](_0x472042),
							this['Magnet']['Update'](),
							this['BGMan']['Update'](_0x472042),
							this['GoldFever']['Update'](_0x472042),
							this['Arcanas']['Update'](_0x472042),
							this['WhiteHandManager']['Update'](_0x472042),
							this['GizmoManager']['Update'](_0x472042);
						for (let _0x393518 = 0; _0x393518 < this['Enemies']['length']; _0x393518++)
							this['Enemies'][_0x393518]['Update'](_0x472042);
						this['Stage']['hasLights'] &&
						(this['spotlight']['x'] = _0x466e41['default']['Core']['Player']['x'],
						 this['spotlight']['y'] = _0x466e41['default']['Core']['Player']['y']);	
		}
		catch(e){
        console.log(e);
		}			
    }
}

module.exports = {
    mods: [
        {
            key: 'overwrite',
            callback: 'Core.Update',
            target: Core.Update
        },

        {
            key: 'overwriteSignature',
            callback: 'Core.Update',
            target: '_0x472042 = 0'
        }
    ]
}
