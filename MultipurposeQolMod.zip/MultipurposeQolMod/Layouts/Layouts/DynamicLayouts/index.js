
const imageLayouts = require('./ImageLayouts')

module.exports = {
    MultipleImageCheckboxLayout: imageLayouts.MultipleImageCheckboxLayout,
    MultipleImageTickerLayout: imageLayouts.MultipleImageTickerLayout
}
