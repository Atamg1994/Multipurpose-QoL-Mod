
module.exports = {
    MultipleImageCheckboxLayout: require('./MultipleImageCheckboxLayout'),
    MultipleImageTickerLayout: require('./MultipleImageTickerLayout')
}
