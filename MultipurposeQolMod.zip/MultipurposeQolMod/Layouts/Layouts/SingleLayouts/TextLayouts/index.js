
module.exports = {
    TextCheckboxLayout: require('./TextCheckboxLayout'),
    TextTickerLayout: require('./TextTickerLayout'),
    TextSliderLayout: require('./TextSliderLayout')
}
