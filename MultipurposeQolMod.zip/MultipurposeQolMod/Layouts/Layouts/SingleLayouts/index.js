
const textLayouts = require('./TextLayouts')

module.exports = {
    TextCheckboxLayout: textLayouts.TextCheckboxLayout,
    TextTickerLayout: textLayouts.TextTickerLayout,
    TextSliderLayout: textLayouts.TextSliderLayout
}
