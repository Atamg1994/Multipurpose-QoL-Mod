
const textLayouts = require('./TextLayouts')

module.exports = {
    DoubleTextCheckboxLayout: textLayouts.DoubleTextCheckboxLayout,
    DoubleTextTickerLayout: textLayouts.DoubleTextTickerLayout,
    TextCheckboxTextTickerLayout: textLayouts.TextCheckboxTextTickerLayout
}
