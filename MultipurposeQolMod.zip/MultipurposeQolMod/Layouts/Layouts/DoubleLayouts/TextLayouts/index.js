
module.exports = {
    DoubleTextCheckboxLayout: require('./DoubleTextCheckboxLayout'),
    DoubleTextTickerLayout: require('./DoubleTextTickerLayout'),
    TextCheckboxTextTickerLayout: require('./TextCheckboxTextTickerLayout')
}
