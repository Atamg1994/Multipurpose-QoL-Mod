
module.exports = {
    PageScrollerLayout: require('./PageScrollerLayout')
}
