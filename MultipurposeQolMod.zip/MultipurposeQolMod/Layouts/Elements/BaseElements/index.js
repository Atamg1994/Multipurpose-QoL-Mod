
module.exports = {
    Text: require('./Text'),
    Image: require('./Image'),
    Sprite: require('./Sprite'),
    Rectangle: require('./Rectangle')
}
