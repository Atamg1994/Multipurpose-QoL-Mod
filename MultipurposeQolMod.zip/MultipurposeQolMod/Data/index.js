
module.exports = {
    Queue: require('./Queue'),
    LayoutData: require('./LayoutData'),

    qolModOptions: require('./defaultModOptions.json'),
    magnetOptions: require('./defaultMagnetOptions.json'),
    limitBreakOptions: require('./defaultLimitBreakOptions.json')
}
